in order to properly run schafs ii, run the .exe as an administrator and simply press ok in the following messagebox :D

made by nquantum#8865